function [F, x, Error] = Per_SOR(x, A, b, omega)
% Per_SOR 执行一步 SOR 迭代更新
% 输入：
%   x     - 当前迭代向量 (n×1)
%   C     - 系数矩阵 (n×n)
%   b     - 右端项向量 (n×1)
%   omega - 松弛因子 (0 < omega < 2)
% 输出：
%   F     - 更新后的残差范数 norm(C*x - b, 2)
%   x     - 更新后的解向量
%   Error - 与 F 相同（为保持接口一致）

    n = length(b);
    x_old = x;  % 保留旧值用于加权

    % 第一个分量
    sum1 = A(1, 2:n) * x_old(2:n);
    x(1) = (1 - omega) * x_old(1) + omega * (b(1) - sum1) / A(1,1);

    % 中间分量
    for i = 2:n-1
        sum1 = A(i, 1:i-1) * x(1:i-1);        % 已更新的部分
        sum2 = A(i, i+1:n) * x_old(i+1:n);    % 尚未更新的部分
        x(i) = (1 - omega) * x_old(i) + omega * (b(i) - sum1 - sum2) / A(i,i);
    end

    % 最后一个分量
    sum1 = A(n, 1:n-1) * x(1:n-1);
    x(n) = (1 - omega) * x_old(n) + omega * (b(n) - sum1) / A(n,n);

    % 计算残差范数（与 Gauss-Seidel 函数一致）
    F = norm(A*x - b, 2);
    Error = F;
end