%per iteration step of Jacobi iteration

function [F,x,Error]=Per_Jacobi(x,C,b)

n=length(b);

x_old=x;

x(1)=(b(1)-C(1,2:n)*x_old(2:n) )/C(1,1);

for i=2:n-1
    x(i)=( b(i)-C(i,1:i-1)*x_old(1:i-1)-C(i,i+1:n)*x_old(i+1:n) )/C(i,i);
end

x(n)=( b(n)-C(n,1:n-1)*x_old(1:n-1) )/C(n,n);


F=norm(C*x-b,2);
Error=norm(C*x-b,2);

end






%% 第二个数值实验的雅可比迭代法
% % Parameters
% delta = 0.2;
% alpha = -1 + delta;
% beta = -1 - delta;
%
% % Define B matrix (10x10)
% B_block = diag(4 * ones(10, 1)) + diag(alpha * ones(9, 1), 1) + diag(beta * ones(9, 1), -1);
%
% % Define Identity matrix (10x10)
% I_block = eye(10);
%
% % Construct the block tridiagonal matrix C_tilde (200x200)
% n_blocks = 20; % Number of 10x10 blocks to reach 200x200 matrix
%
% % Main diagonal blocks filled with B_block
% main_diag = kron(eye(n_blocks), B_block);
%
% % Upper and lower diagonal blocks filled with -I_block
% upper_diag = kron(diag(ones(n_blocks-1, 1), 1), -I_block);
% lower_diag = kron(diag(ones(n_blocks-1, 1), -1), -I_block);
%
% % Combine to form C_tilde
% C_tilde = main_diag + upper_diag + lower_diag;
%
% % Define the identity matrix and construct A
% n = size(C_tilde, 1); % Dimension of C_tilde (should be 200x200)
% %I = eye(n); % Identity matrix of size n
% A =C_tilde;
%
% % Define the exact solution s as a vector of ones
% s = ones(n, 1);
%
% % Calculate the corresponding b vector for the original system
% b = C_tilde * s;
% % Extract the diagonal and off-diagonal parts of A for Jacobi method
% D = diag(diag(A)); % Diagonal part of A
% R = A - D; % Remaining part of A (non-diagonal elements)
%
% % 雅可比迭代
% F = inv(D) *(b - R * X);
%
% nF = norm(X-F);
% X = F; % 更新解



