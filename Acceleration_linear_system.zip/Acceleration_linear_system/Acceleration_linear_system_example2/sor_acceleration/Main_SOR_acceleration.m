% This is the main precedure of Jacobi iteration and various vector
% extrapolation methods for solving the linear system Ax=b


clc
clear
close all
format long
opts.tol = 1e-8;
opts.mxitr = 10000;


% Problem dimensions
NX = [15,20,30,35,45,50];
NY = [20,20,20,20,20,20];
noise=0.1;
long_listN = length(NX);
omega=1.6;

% Parameters for acceleration methods
m_MPE_RRE_MMPE = [4,5];
m_Anderson = [4,5];
m_epslion = [7,8];

% Display header
disp('----Numerical results of Jacobi iteration and its acceleration-----------');
fprintf('%15s\t %2s\t %6s\t %8s\t %8s\t \n', ...
    'method','n','CPU','IT','Residual');

t=tiledlayout(2, 3,'TileSpacing','compact');
% Loop over different problem sizes
for i = 1:long_listN

    % Generate input matrices and initial matrices
    nx=NX(i);ny=NY(i);
    [C,b,~] = generate_gravity_test(nx,ny,noise);
    n = length(b);   % 或 n = nx*ny;
    x = zeros(n,1);

    % Define available methods
    methods = {'SOR', 'SOR-MPE', 'SOR-RRE', 'SOR-MMPE', 'SOR-SVDMPE','SOR-Anderson','SOR-VEA','SOR-TEA','SOR-STEA'};

    % Perform each method using switch-case
    for method_index = 1:length(methods)
        method = methods{method_index};
        switch method
            case 'SOR'
                out = runMethod('SOR', @FPI, x,C,b,opts,omega);
                TT_FPI=out.TT;

            case 'SOR-MPE'
                for j = 1:length(m_MPE_RRE_MMPE)
                    if j == 2
                        out = runMethod('SOR-MPE', @FPI_MPE_RRE, x,C,b,opts,'MPE', m_MPE_RRE_MMPE(j),omega);
                        TT_MPE=out.TT;
                    else
                        runMethod('SOR-MPE', @FPI_MPE_RRE, x,C,b,opts,'MPE', m_MPE_RRE_MMPE(j),omega);
                    end
                end

            case 'SOR-RRE'
                for j = 1:length(m_MPE_RRE_MMPE)
                    if j == 2
                        out = runMethod('SOR-RRE', @FPI_MPE_RRE, x,C,b,opts,'RRE', m_MPE_RRE_MMPE(j),omega);
                        TT_RRE=out.TT;
                    else
                        runMethod('SOR-RRE', @FPI_MPE_RRE, x,C,b,opts,'RRE', m_MPE_RRE_MMPE(j),omega);
                    end
                end

            case 'SOR-MMPE'
                for j = 1:length(m_MPE_RRE_MMPE)
                    if j == 2
                        out = runMethod('SOR-MMPE', @FPI_MMPE, x,C,b,opts, m_MPE_RRE_MMPE(j),omega);
                        TT_MMPE=out.TT;
                    else
                        runMethod('SOR-MMPE', @FPI_MMPE, x,C,b,opts, m_MPE_RRE_MMPE(j),omega);
                    end
                end

            case 'SOR-Anderson'
                for j = 1:length(m_Anderson)
                    if j == 2
                        out = runMethod('SOR-Anderson', @FPI_Anderson, x,C,b,opts, m_Anderson(j),omega);
                        TT_Anderson=out.TT;
                    else
                        runMethod('SOR-Anderson', @FPI_Anderson, x,C,b,opts, m_Anderson(j),omega);
                    end
                end

            case 'SOR-VEA'
                for j = 1:length(m_epslion)
                    if j == 1
                        out = runMethod('SOR-VEA', @FPI_VEA, x,C,b,opts, m_epslion(j),omega);
                        TT_VEA=out.TT;
                    else
                        runMethod('SOR-VEA', @FPI_VEA, x,C,b,opts, m_epslion(j),omega);
                    end
                end

            case 'SOR-TEA'
                for j = 1:length(m_epslion)
                    if j == 1
                        out = runMethod('SOR-TEA', @FPI_TEA, x,C,b,opts, m_epslion(j),omega);
                        TT_TEA=out.TT;
                    else
                        runMethod('SOR-TEA', @FPI_TEA, x,C,b,opts, m_epslion(j),omega);
                    end
                end

            case 'SOR-STEA'
                for j = 1:length(m_epslion)
                    if j == 1
                        out = runMethod('SOR-STEA', @FPI_STEA2_3, x,C,b,opts, m_epslion(j),omega);
                        TT_STEA=out.TT;
                    else
                        runMethod('SOR-STEA', @FPI_STEA2_3, x,C,b,opts, m_epslion(j),omega);
                    end
                end
        end
    end
    disp('----------------------------------------------------------------------------');

    %% Plot the results for the current case
    figure(i)
    hold on;
    colors = [0 0 1; 1 0 0; 0 1 0; 0 1 1; 1 0 1; 0 0 0; 1 0.5 0; 0.5 0.5 1; 1 0.5 1; 0.5 1 0.5; 0.5 1 1; 1 1 0.5];
    % blue-1, red-2, green-3, cyan-4, magenta-5, black-6, orange-7,
    %light blue-8, pink-9, light green-10, light cyan-11, light yellow-12
    marker_shapes = {'s', 'o', '^', 'd', 'p', 'h', '+', '*', 'x', '.', 'v', '<', '>', '|', '_',};
    % Plot Error vs Iteration Steps
    h_FI = plot(log10(TT_FPI), 'Color', colors(6, :), 'Marker', marker_shapes{1}, 'LineStyle', '-', 'Markersize', 7, 'LineWidth', 1);
    h_MPE = plot(log10(TT_MPE), 'Color', colors(4, :), 'Marker', marker_shapes{2}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    h_RRE = plot(log10(TT_RRE), 'Color', colors(2, :), 'Marker', marker_shapes{3}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h_MMPE = plot(log10(TT_MMPE), 'Color', colors(8, :), 'Marker', marker_shapes{4}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
%     h_SVDMPE = plot(log10(TT_SVDMPE), 'Color', colors(10, :), 'Marker', marker_shapes{5}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    h_Anderson = plot(log10(TT_Anderson), 'Color', colors(7, :), 'Marker', marker_shapes{5}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h_VEA = plot(log10(TT_VEA), 'Color', colors(1, :), 'Marker', marker_shapes{6}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h_TEA = plot(log10(TT_TEA), 'Color', colors(3, :), 'Marker', marker_shapes{7}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    h_STEA = plot(log10(TT_STEA), 'Color', colors(5, :), 'Marker', marker_shapes{8}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h=legend([h_FI,h_MPE,h_RRE,h_MMPE,h_Anderson,h_VEA,h_TEA,h_STEA],'SOR', 'SOR-MPE (k=5)', 'SOR-RRE (k=5)', 'SOR-MMPE (k=5)', 'SOR-Anderson (k=5)', 'SOR-VEA (k=7)', 'SOR-TEA (k=7)', 'SOR-STEA (k=7)');

    set(h,'Fontsize',10, 'FontWeight', 'bold','Location', 'Northeast');
    xlabel('Iteration Steps', 'Interpreter', 'latex','FontSize', 14);
    ylabel('$\mathrm{log}_{10}\|\mathrm{Residual}\|$', 'Interpreter', 'latex', 'fontsize', 15);
    set(gca,'LineWidth',1)
    set(gca,'FontSize',20)
    title(['SOR , ','$\omega$ = 1.6 , ','n=Nx*Ny=',num2str(n)],'Interpreter', 'latex','fontsize',18)
    epsname = sprintf('case2-SOR-%d.eps', n);
    saveas(gcf, epsname, 'epsc');
    pngname = sprintf('case2-SOR-%d.png', n);
    saveas(gcf, pngname, 'png');   
    hold off
   
end



%% Run a Specific Method
function out = runMethod(methodName, methodHandle, x,C,b,opts, varargin)
tic;
out = feval(methodHandle, x, C, b, opts, varargin{:});
time = toc;
fprintf('%15s\t %2d\t %3.3f\t %4d\t %4.2e\t  \n', ...
    methodName, size(C, 1), time, out.itr, out.Residual);
end
