function [out] = FPI_TEA(x,C,b, opts, mMax,omega)


% Initialize variables
MAXCOL = 8;
NBC=2*mMax+1;
TOL = 1e-20;
Y = ones(size(x(:)));  % Vector Y initialized to ones
TT = [];               % Error_1 history


% Main loop for fixed-point iteration with Second Topological Epsilon Algorithm
for cycle = 1:opts.mxitr

        [F,x,Error]=Per_SOR(x,C,b,omega);
        TT(end+1) = F;     
        
          if  F < opts.tol 
            out.itr = length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
          end
        
        % Store the current Q for further epsilon iteration
        EPSINI = x;
        [EPSINI,EPSVEC]=TEA2(EPSINI,[],MAXCOL,Y,TOL,0);
    
    % Second Topological Epsilon Algorithm for extrapolation
   for n = 1:NBC-1
        [F,x,Error]=Per_SOR(x,C,b,omega);
        TT(end+1) = F;
        
        if  F < opts.tol 
            out.itr = length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end
        EPSINI = x;
        [EPSINI,EPSVEC]=TEA2(EPSINI,EPSVEC,MAXCOL,Y,TOL);

   end
   x=EPSINI;
end

% Final output structure
out.itr =length(TT);
out.Residual = F;
out.Error = Error;
out.TT = TT;

end
