function [C, b, grid] = generate_gravity_test(Nx, Ny, noise_level)
% generate_gravity_test 生成基于地球物理背景的合成测试数据
%   输入：
%       Nx, Ny      - 网格点数（x 和 y 方向）
%       noise_level - 可选，添加到右端项的高斯噪声标准差（默认 0）
%   输出：
%       C      - 五点差分矩阵 (Nx*Ny × Nx*Ny)，即线性系统的系数矩阵
%       b      - 右端项向量
%       x_true - 真实解（未知，返回空数组）
%       grid   - 结构体，包含网格坐标和密度分布
%
%   说明：该函数生成与地球物理重力勘探相关的泊松方程离散化矩阵和右端项。
%         系数矩阵 C 可直接用于迭代法求解

    if nargin < 3, noise_level = 0; end

    % 区域大小（参考论文：110 km × 50 km）
    Lx = 110e3;  % 米
    Ly = 50e3;
    hx = Lx / (Nx + 1);
    hy = Ly / (Ny + 1);

    % 生成五点差分矩阵 A（内部使用）
    e = ones(Nx,1);
    Tx = spdiags([-e/hx^2, 2*e/hx^2, -e/hx^2], -1:1, Nx, Nx);
    e = ones(Ny,1);
    Ty = spdiags([-e/hy^2, 2*e/hy^2, -e/hy^2], -1:1, Ny, Ny);
    Ix = speye(Nx); Iy = speye(Ny);
    A = kron(Iy, Tx) + kron(Ty, Ix);  % 五点差分矩阵

    % 生成网格点坐标
    x = linspace(hx, Lx-hx, Nx)';
    y = linspace(hy, Ly-hy, Ny)';
    [X, Y] = meshgrid(x, y);

    % 定义密度分布（单位：g/cm³）
    rho_background = 2.67;
    rho_salt = 2.20;
    
    % 盐丘区域：椭圆形状，中心在 (40km, 25km)
    Xc = 40e3; Yc = 25e3;
    a = 15e3; b_ell = 8e3;  % 短半轴改名为 b_ell
    dist = ((X - Xc)/a).^2 + ((Y - Yc)/b_ell).^2;
    in_salt = dist <= 1;
    
    rho = rho_background * ones(size(X));
    rho(in_salt) = rho_salt;

    % 转换为 kg/m³ 并计算右端项 b = -4πGρ * (hx*hy)
    G_const = 6.67430e-11;  % 引力常数
    rho_kg = rho * 1000;  % g/cm³ -> kg/m³
    b = -4 * pi * G_const * rho_kg(:) * (hx * hy);

    % 可选：添加噪声模拟测量误差
    if noise_level > 0
        rng(0);  % 固定种子保证可重复性
        noise = noise_level * randn(size(b));
        b = b + noise;
    end


    % 存储网格信息
    grid.X = X; grid.Y = Y; grid.rho = rho;
    grid.hx = hx; grid.hy = hy;
    
    % 将系数矩阵赋值给输出参数 C
    C = A;
end