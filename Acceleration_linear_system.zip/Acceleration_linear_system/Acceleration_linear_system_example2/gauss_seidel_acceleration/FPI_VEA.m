function [out] = FPI_VEA(x,C,b, opts, mMax)

MAXCOL = 4;
NDIGIT = 15;
NBC=2*mMax+1;
TOL = 1e-20;
TT=[];


% Main loop for fixed-point iteration with Vector Epsilon Algorithm (VEA)
  for cycle = 1:opts.mxitr
    [F, x, Error] = Per_Gauss_Siedel(x,C,b);
     TT(end+1) = F;
  
        if  F < opts.tol 
            out.itr =length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end
        
        EPSINI=x;
       [EPSINI,EPSVEC,~]=VEAW(EPSINI,[],MAXCOL,TOL,NDIGIT,0);
 
 
      for n = 1:NBC-1
        [F, x, Error] = Per_Gauss_Siedel(x,C,b);
        TT(end+1)=F; 

        if  F < opts.tol       
            out.itr = length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end

        EPSINI =x;
        [EPSINI,EPSVEC,~]=VEAW(EPSINI,EPSVEC,MAXCOL,TOL,NDIGIT);
      end
    x =EPSINI; 

  end
    

% Final output structure
out.itr =length(TT);
out.Residual = F;
out.Error = Error;
out.TT = TT;

end
