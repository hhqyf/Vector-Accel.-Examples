function [out] = FPI_MPE_RRE(x,C,b, opts,method, mMax)
% FI_MPE_RRE - JACOBI iteration with MPE and RRE acceleration for solving
% the linear system Ax=b.
%
% Syntax: [out] = FI_MPE_RRE(Q1, fun, opts, X, mcas, method, mMax)
%
% Inputs:
%   Q1     - Initial matrix Q1
%   fun    - Function handle for fixed-point iteration
%   opts   - Options structure containing:
%             opts.mxitr - Maximum number of iterations
%             opts.tol   - Tolerance for stopping criterion
%   X      - Input data
%   mcas   - Miscellaneous parameters
%   method - Acceleration method ('MPE' or 'RRE')
%   mMax   - Maximum number of acceleration steps
%
% Outputs:
%   out    - Structure containing:
%             out.itr    - Number of iterations performed
%             out.fval   - Final function value
%             out.Error_1 - Final Error_1
%             out.Error_2 - Final Error_2
%             out.TT     - Error_1 history

% Ensure long format for output
format long;

% Initialize variables
QQ = [];
TT = [];

x0=x;

iter1 =0; 
% Main loop for fixed-point iteration with MPE/RRE acceleration
for iter = 1:opts.mxitr
    [F, x, Error] = Per_Gauss_Siedel(x,C,b);
    TT(iter+iter1) = F;
    QQ(:, 1) = x;
    
    % Check stopping criteria
    if Error < opts.tol || F < opts.tol 
        break;
    end


    % Perform MPE/RRE acceleration over mMax steps
    for i = 1:mMax
        [F,x, Error] = Per_Gauss_Siedel (x,C,b);
        iter1 = iter1+ 1;
        TT(iter+iter1) = F;
        QQ(:, i + 1) = x;
        
        % Early stopping if convergence is met
        if Error < opts.tol || F < opts.tol 
            out.itr = iter + iter1;
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end
    end
    
    % Compute differences between consecutive QQ columns
    QQ(:, 2:end) = QQ(:, 2:end) - QQ(:, 1:end-1);
    QQ(:, 1) = QQ(:, 1) - x0;
    
    % Apply MPE or RRE method based on the selected option
    [~, R] = mgs(QQ); % Modified Gram-Schmidt
    switch method
        case 'RRE'
            y = R' \ ones(mMax + 1, 1);
            gamma = R \ y;
            gamma = gamma(:) / sum(gamma); % Normalize
        case 'MPE'
            gamma = pinv(R(1:end-1, 1:end-1)) * R(1:end-1, end);
            gamma = [-gamma; 1]; % Append 1 to gamma
            gamma = gamma / sum(gamma); % Normalize
    end
    
    % Update Q1 using the computed gamma values
    xi = 1 - cumsum(gamma(1:mMax + 1));
    x = x0 + QQ(:, 1:mMax + 1) * xi;
    
end

% Final output structure
out.itr = iter + iter1;
out.Residual = F;
out.Error = Error;
out.TT = TT;

end

function [Q, R] = mgs(Q)
% MGS - Modified Gram-Schmidt orthogonalization
%
% Syntax: [Q, R] = mgs(Q)
%
% Inputs:
%   Q - Matrix to be orthogonalized
%
% Outputs:
%   Q - Orthogonalized matrix
%   R - Upper triangular matrix from QR decomposition

[~, M] = size(Q);
R = zeros(M);
for i = 1:M
    for j = 1:i-1
        r = Q(:, j)' * Q(:, i);
        Q(:, i) = Q(:, i) - r * Q(:, j);
        R(j, i) = r;
    end
    R(i, i) = norm(Q(:, i));
    Q(:, i) = Q(:, i) / R(i, i);
end

end
