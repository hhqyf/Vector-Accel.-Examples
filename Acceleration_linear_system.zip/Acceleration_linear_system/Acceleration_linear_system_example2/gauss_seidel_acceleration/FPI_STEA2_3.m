function [out] = FPI_STEA2_3(x,C,b, opts, mMax)

MAXCOL = 4;
NDIGIT = 15;
NBC=2*mMax+1;
TOL = 1e-20;
Y = ones(size(x));   % Initialize Y to ones
TT = [];             % Error history initialization


% Main iteration loop
for  cycle = 1:opts.mxitr
  
        [F, x, Error] = Per_Gauss_Siedel(x,C,b);
        TT(end+1) = F;
        
        if F < opts.tol 
            out.itr =length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end
      % First value <y,u_0>
      EPSINIS = trace(Y'*x);        
     % First call of the scalar epsilon-algorithm
     [EPSINIS,EPSSCA,NSING] = SEAW(EPSINIS,[],MAXCOL,TOL,NDIGIT,0);

     % First call (initialization) of STEA algorithm
     [EPSINI,EPSVEC] = STEA2_3(x,[],EPSSCA,MAXCOL,TOL,0);
    
    % Apply the second topological epsilon algorithm (STEA2_3)
    for n = 1:NBC-1

        [F, x, Error] = Per_Gauss_Siedel(x,C,b);
        TT(end+1) = F;
     
        if  F < opts.tol 
            out.itr = length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end        

        EPSINIS = trace(Y'*x);

        % Next call of the scalar epsilon-algorithm
        [EPSINIS,EPSSCA,NSING]= SEAW(EPSINIS,EPSSCA,MAXCOL,TOL,NDIGIT);

        % Next element u_i
        EPSINI = x;

        % Next call of STEA algorithm
        [EPSINI,EPSVEC]=STEA2_3(EPSINI,EPSVEC,EPSSCA,MAXCOL,TOL);
    end
    x = EPSINI;
    
end

% Final output structure
out.itr = length(TT);
out.Residual = F;
out.Error= Error;
out.TT = TT;

end
