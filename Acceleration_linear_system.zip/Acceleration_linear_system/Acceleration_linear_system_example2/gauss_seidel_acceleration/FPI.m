function [out]=FPI(x,C,b,opts)

format long

TT=[]; % TT is used to store the error at each iteration.

for iter = 1:opts.mxitr

    [F,x,Error]=Per_Gauss_Siedel(x,C,b);

    TT(iter)=F;

    if F<opts.tol || Error<opts.tol

        break
    end
end

out.itr = iter;
out.Residual = F;
out.Error=Error;
out.TT=TT;

