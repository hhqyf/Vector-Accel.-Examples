%per iteration step of Gauss-Seidel iteration

function [F,x,Error]=Per_Gauss_Siedel(x,C,b)

n=length(b);

x_old=x;

x(1)=(b(1)-C(1,2:n)*x_old(2:n) )/C(1,1);

for i=2:n-1
    x(i)=( b(i)-C(i,1:i-1)*x(1:i-1)-C(i,i+1:n)*x_old(i+1:n) )/C(i,i);
end

x(n)=( b(n)-C(n,1:n-1)*x(1:n-1) )/C(n,n);



F=norm(C*x-b,2);
Error=norm(x-ones(n,1),2);


end