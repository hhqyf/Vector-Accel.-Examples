%% This is the main precedure of Gauss-Siedel iteration and various vector
%% extrapolation methods for solving the linear system Ax=b


clc
clear
close all
format long
opts.tol = 1e-8;
opts.mxitr = 1000;


% Problem dimensions
N = [500,600,700,800,900,1000];
long_listN = length(N);

% Parameters for acceleration methods
m_MPE_RRE_MMPE = [4,5];
m_Anderson = [4,5];
m_epslion = [4,5];

% Display header
disp('------Numerical results of Gauss-Siedel and its acceleration-----------');
fprintf('%15s\t %2s\t %6s\t %8s\t %8s\t \n', ...
    'method','n','CPU','IT','Residual');

t=tiledlayout(2, 3,'TileSpacing','compact');
% Loop over different problem sizes
for i = 1:long_listN
    n = N(i);

    % Generate input matrices and initial matrices
    [C,b] = generateMatrices(n);
    x=zeros(n,1);

    % Define available methods
    methods = {'Gauss-Siedel', 'G-S-MPE', 'G-S-RRE', 'G-S-MMPE', 'G-S-SVDMPE','G-S-Anderson','G-S-VEA','G-S-TEA','G-S-STEA'};

    % Perform each method using switch-case
    for method_index = 1:length(methods)
        method = methods{method_index};
        switch method
            case 'Gauss-Siedel'
                out = runMethod('Gauss-Siedel', @Gauss_Seidel, x,C,b,opts);
                TT_FPI=out.TT;

            case 'G-S-MPE'
                for j = 1:length(m_MPE_RRE_MMPE)
                    if j == 2
                        out = runMethod('G-S-MPE', @G_S_MPE_RRE, x,C,b,opts,'MPE', m_MPE_RRE_MMPE(j));
                        TT_MPE=out.TT;
                    else
                        runMethod('G-S-MPE', @G_S_MPE_RRE, x,C,b,opts,'MPE', m_MPE_RRE_MMPE(j));
                    end
                end

            case 'G-S-RRE'
                for j = 1:length(m_MPE_RRE_MMPE)
                    if j == 2
                        out = runMethod('G-S-RRE', @G_S_MPE_RRE, x,C,b,opts,'RRE', m_MPE_RRE_MMPE(j));
                        TT_RRE=out.TT;
                    else
                        runMethod('G-S-RRE', @G_S_MPE_RRE, x,C,b,opts,'RRE', m_MPE_RRE_MMPE(j));
                    end
                end

            case 'G-S-MMPE'
                for j = 1:length(m_MPE_RRE_MMPE)
                    if j == 2
                        out = runMethod('G-S-MMPE', @G_S_MMPE, x,C,b,opts, m_MPE_RRE_MMPE(j));
                        TT_MMPE=out.TT;
                    else
                        runMethod('G-S-MMPE', @G_S_MMPE, x,C,b,opts, m_MPE_RRE_MMPE(j));
                    end
                end

            case 'G-S-Anderson'
                for j = 1:length(m_Anderson)
                    if j == 2
                        out = runMethod('G-S-Anderson', @G_S_Anderson, x,C,b,opts, m_Anderson(j));
                        TT_Anderson=out.TT;
                    else
                        runMethod('G-S-Anderson', @G_S_Anderson, x,C,b,opts, m_Anderson(j));
                    end
                end

            case 'G-S-VEA'
                for j = 1:length(m_epslion)
                    if j == 2
                        out = runMethod('G-S-VEA', @G_S_VEA, x,C,b,opts, m_epslion(j));
                        TT_VEA=out.TT;
                    else
                        runMethod('G-S-VEA', @G_S_VEA, x,C,b,opts, m_epslion(j));
                    end
                end

            case 'G-S-TEA'
                for j = 1:length(m_epslion)
                    if j == 2
                        out = runMethod('G-S-TEA', @G_S_TEA, x,C,b,opts, m_epslion(j));
                        TT_TEA=out.TT;
                    else
                        runMethod('G-S-TEA', @G_S_TEA, x,C,b,opts, m_epslion(j));
                    end
                end

            case 'G-S-STEA'
                for j = 1:length(m_epslion)
                    if j == 2
                        out = runMethod('G-S-STEA', @G_S_STEA2_3, x,C,b,opts, m_epslion(j));
                        TT_STEA=out.TT;
                    else
                        runMethod('G-S-STEA', @G_S_STEA2_3, x,C,b,opts, m_epslion(j));
                    end
                end
        end
    end
    disp('----------------------------------------------------------------------------');

    %% Plot the results for the current case
    figure(i)
    hold on;
    colors = [0 0 1; 1 0 0; 0 1 0; 0 1 1; 1 0 1; 0 0 0; 1 0.5 0; 0.5 0.5 1; 1 0.5 1; 0.5 1 0.5; 0.5 1 1; 1 1 0.5];
    % blue-1, red-2, green-3, cyan-4, magenta-5, black-6, orange-7,
    %light blue-8, pink-9, light green-10, light cyan-11, light yellow-12
    marker_shapes = {'s', 'o', '^', 'd', 'p', 'h', '+', '*', 'x', '.', 'v', '<', '>', '|', '_',};
    % Plot Error vs Iteration Steps
    h_FI = plot(log10(TT_FPI), 'Color', colors(6, :), 'Marker', marker_shapes{1}, 'LineStyle', '-', 'Markersize', 7, 'LineWidth', 1);
    h_MPE = plot(log10(TT_MPE), 'Color', colors(4, :), 'Marker', marker_shapes{2}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    h_RRE = plot(log10(TT_RRE), 'Color', colors(2, :), 'Marker', marker_shapes{3}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h_MMPE = plot(log10(TT_MMPE), 'Color', colors(8, :), 'Marker', marker_shapes{4}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    h_Anderson = plot(log10(TT_Anderson), 'Color', colors(7, :), 'Marker', marker_shapes{5}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h_VEA = plot(log10(TT_VEA), 'Color', colors(1, :), 'Marker', marker_shapes{6}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h_TEA = plot(log10(TT_TEA), 'Color', colors(3, :), 'Marker', marker_shapes{7}, 'LineStyle', '-.', 'Markersize', 7, 'LineWidth', 1);
    h_STEA = plot(log10(TT_STEA), 'Color', colors(5, :), 'Marker', marker_shapes{8}, 'LineStyle', ':', 'Markersize', 7, 'LineWidth', 1);
    h=legend([h_FI,h_MPE,h_RRE,h_MMPE,h_Anderson,h_VEA,h_TEA,h_STEA],'Gauss-Siedel', 'G-S-MPE (k=5)', 'G-S-RRE (k=5)', 'G-S-MMPE (k=5)', 'G-S-Anderson (k=5)', 'G-S-VEA (k=5)', 'G-S-TEA (k=5)', 'G-S-STEA (k=5)');
   
    set(h,'Fontsize',10, 'FontWeight', 'bold','Location', 'Northeast');
    set(gca, 'LineWidth', 1, 'fontsize', 20);
    xlabel('Iteration Steps', 'Interpreter', 'latex','fontsize',18);
    ylabel('$\mathrm{log}_{10}\|\mathrm{Residual}\|$', 'Interpreter', 'latex', 'fontsize',20);
    title(['Gauss-Siedel , ','n=',num2str(n)],'Interpreter', 'latex','fontsize',16);
    epsname = sprintf('case1-Gauss-Siedel-%d.eps', n);
    saveas(gcf, epsname, 'epsc');
    pngname = sprintf('case1-Gauss-Siedel-%d.png', n);
    saveas(gcf, pngname, 'png');   
    hold off
    hold off;   
end



%% Run a Specific Method
function out = runMethod(methodName, methodHandle, x,C,b,opts, varargin)
tic;
out = feval(methodHandle, x, C, b, opts, varargin{:});
time = toc;
fprintf('%15s\t %2d\t %3.3f\t %4d\t %4.2e\t \n', ...
    methodName, size(C, 1), time, out.itr, out.Residual);
end
