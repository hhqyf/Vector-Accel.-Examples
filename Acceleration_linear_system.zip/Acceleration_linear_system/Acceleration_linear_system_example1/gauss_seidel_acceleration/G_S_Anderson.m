function [out] = G_S_Anderson(x,C,b, opts, mMax)
% FI_Anderson - JACOBI iteration with Anderson acceleration for solving
% the linear system Ax=b.
%
% Syntax: [out] = FI_Anderson(Q1, fun, opts, S, K, mMax)
%
% Inputs:
%   Q1     - Initial matrix Q1
%   fun    - Function handle for fixed-point iteration
%   opts   - Options structure containing:
%             opts.mxitr - Maximum number of iterations
%             opts.tol   - Tolerance for convergence
%   S      - Input data
%   K      - Miscellaneous parameters
%   mMax   - Maximum history length for Anderson acceleration
%
% Outputs:
%   out    - Structure containing:
%             out.itr    - Number of iterations performed
%             out.fval   - Final function value
%             out.Error_1 - Final Error_1
%             out.Error_2 - Final Error_2
%             out.TT     - Error history

% Set default parameters
ls_solve = 'u';    % Least-squares solve method ('u': QR update, 'n': normal equations, 'b': backslash)
droptol = 0;       % Drop tolerance for conditioning improvement
AAstart = 1;       % Delay for Anderson acceleration start

% Initialize storage arrays
DG = [];  % Storage for differences in g-values
DF = [];  % Storage for differences in f-values (needed for 'n' and 'b' options)
mAA = 0;  % Number of stored residuals
TT = [];  % Error history





% Main iteration loop
for iter = 1:opts.mxitr
    % Perform the fixed-point iteration
    [F, xnew, Error] = Per_Gauss_Siedel(x,C,b);
    TT(iter) = F;
    
    gval = xnew;
    fval = gval - x;
    
    % Check convergence
    if Error < opts.tol || F < opts.tol 
        break;
    end
    
    if mMax == 0 || iter < AAstart
        % No acceleration, update x <- g(x)
        x = gval;
    else
        % Anderson acceleration
        if iter > AAstart
            % Compute differences between current and previous iterations
            df = fval - f_old;
            if mAA < mMax
                DG = [DG, gval - g_old];
                if ls_solve ~= 'u'
                    DF = [DF, df];
                end
            else
                DG(:, 1) = [];
                DG(:, mAA) = gval - g_old;
                if ls_solve ~= 'u'
                    DF(:, 1) = [];
                    DF(:, mAA) = df;
                end
            end
            mAA = mAA + 1;
        end
        
        f_old = fval;
        g_old = gval;
        
        if mAA == 0
            x = gval;  % Update x <- g(x)
        else
            % Solve the least-squares problem
            switch ls_solve
                case 'u'  % QR factorization with updating
                    if mAA == 1
                        R(1, 1) = norm(df);
                        Q = df / R(1, 1);
                    else
                        if mAA > mMax
                            [Q, R] = qrdelete(Q, R, 1);
                            mAA = mAA - 1;
                            if size(R, 1) ~= size(R, 2)
                                Q = Q(:, 1:mAA - 1);
                                R = R(1:mAA - 1, :);
                            end
                        end
                        for j = 1:mAA - 1
                            R(j, mAA) = Q(:, j)' * df;
                            df = df - R(j, mAA) * Q(:, j);
                        end
                        R(mAA, mAA) = norm(df);
                        Q = [Q, df / R(mAA, mAA)];
                    end
                    
                    if droptol > 0
                        condDF = cond(R);
                        while condDF > droptol && mAA > 1
                            [Q, R] = qrdelete(Q, R, 1);
                            DG = DG(:, 2:mAA);
                            mAA = mAA - 1;
                            if size(R, 1) ~= size(R, 2)
                                Q = Q(:, 1:mAA);
                                R = R(1:mAA, :);
                            end
                            condDF = cond(R);
                        end
                    end
                    
                    gamma = R \ (Q' * fval);
                    
                case 'n'  % Normal equations
                    if mAA > mMax, mAA = mAA - 1; end
                    c = DF' * fval;
                    [~, R] = qr(DF, 0);
                    y = R' \ c;
                    gamma = R \ y;
                    
                case 'b'  % Backslash method
                    if mAA > mMax, mAA = mAA - 1; end
                    gamma = DF \ fval;
            end
            
            % Update the solution
            x = gval - DG * gamma;
        end
    end
    

    
end

% Output the results
out.itr = iter;
out.Residual = F;
out.Error = Error;
out.TT = TT;

end
