function [C,b]= generateMatrices(n)

% Initialize a sparse matrix
A = sparse(n, n);

% Define scaling factor
scale = 0.06;

% Fill the matrix according to the specified pattern
A(1, 1) = scale * 5;
A(1, 2) = scale * 2;
A(1, 3) = scale * 1;
A(1, 4) = scale * 1;

A(2, 1) = scale * 2;
A(2, 2) = scale * 6;
A(2, 3) = scale * 3;
A(2, 4) = scale * 1;
A(2, 5) = scale * 1;

A(3, 1) = scale * 1;
A(3, 2) = scale * 3;
A(3, 3) = scale * 6;
A(3, 4) = scale * 3;
A(3, 5) = scale * 1;
A(3, 6) = scale * 1;

% Fill the rest of the rows starting from the fourth row
for i = 4:n
    A(i, i-3) = scale * 1;
    A(i, i-2) = scale * 1;
    A(i, i-1) = scale * 3;
    A(i, i) = scale * 6;
    
    if i+1 <= n
        A(i, i+1) = scale * 3;
    end
    if i+2 <= n
        A(i, i+2) = scale * 1;
    end
    if i+3 <= n
        A(i, i+3) = scale * 1;
    end
end

% Convert sparse matrix to full matrix
A = full(A);

C=eye(n)-A;

b=C* ones(n,1);