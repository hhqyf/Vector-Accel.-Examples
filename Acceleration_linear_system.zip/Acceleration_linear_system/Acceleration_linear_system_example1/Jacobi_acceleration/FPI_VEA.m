function [out] = FPI_VEA(x,C,b, opts, mMax)

MAXCOL = 4;
NDIGIT = 15;
NBC=2*mMax+1;
TOL = 1e-20;
TT=[];

% Let run some basic iteration before applying the VEA accerleration
itr_ini=0;
itr=0;
iter1=0;

% Main loop for fixed-point iteration with Vector Epsilon Algorithm (VEA)
for cycle = 1:opts.mxitr
        [F, x, Error] = Per_Jacobi(x,C,b);
        TT(end+1) = F;
        iter1=iter1+1;
        % Check stopping criteria
        if Error < opts.tol || F < opts.tol 
            itr = itr+1;
            out.itr =length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end
        
        EPSINI=x;
       [EPSINI,EPSVEC,~]=VEAW(EPSINI,[],MAXCOL,TOL,NDIGIT,0);
 
 
        for n = 1:NBC-1
        [F, x, Error] = Per_Jacobi(x,C,b);
        itr=(cycle-1)*(NBC-1)+itr_ini+n+iter1;

        TT(end+1)=F; 

        if Error < opts.tol || F < opts.tol 
            itr = itr+1;
            out.itr = length(TT);
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end

        EPSINI =x;
        [EPSINI,EPSVEC,~]=VEAW(EPSINI,EPSVEC,MAXCOL,TOL,NDIGIT);
    end
        x =EPSINI; % Update Q with the final value of W
    end
    

% Final output structure
out.itr =length(TT);
out.Residual = F;
out.Error = Error;
out.TT = TT;

end
