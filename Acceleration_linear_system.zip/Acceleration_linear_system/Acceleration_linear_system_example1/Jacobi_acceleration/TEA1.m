function [EPSINI,EPSVEC] = TEA1(EPSINI,EPSVEC,MAXCOL,Y,TOL,IFLAG) 
persistent INDM 
persistent EPSDIF   
%
%                        ... EXECUTABLE STATEMENTS
%
%                        ... CHECK THE ARGUMENTS
if nargin < 5               % CHECK the number of input arguments
    error(' TEA1 - Not enought input arguments ')
elseif nargout < 2          % CHECK the number of output arguments
    error(' TEA1 - Not enought output arguments ')
elseif (mod(MAXCOL,2) ~= 0) || MAXCOL < 0 % CHECK MAXCOL 
    error(' TEA1 - MAXCOL must be a positive even integer number')
end
%
%                        ... FIRST CALL OF THE FUNCTION WITH IFLAG == 0 
%                            OR TRIVIAL CASE (MAXCOL == 0)
if ((nargin == 6) && (IFLAG == 0)) || (MAXCOL == 0)
%                        ... INITIALIZE THE COUNTER INDM
%       INDM is a counter for the calls of the function. The function
%       at each call computes the INDM+1 backward diagonal (not used
%       in the trivial case, that is when MAXCOL == 0)
    INDM   = 0;
%
%                        ... SET THE BACKWARD DIAGONAL EQUAL TO eps_0^{(0)}
%                            OR TO eps_0^{(n}) (IN THE TRIVIAL CASE)
    EPSVEC{1} = EPSINI;  
    EPSDIF{1} = [];
    return
%
%                        ... END OF THE FIRST CALL OF THE FUNCTION OR
%                            TRIVIAL CASE (MAXCOL == 0)
end
%                        ... NEXT CALLS OF THE FUNCTION
%
%                        ... UPDATE INDM (IT REPRESENTS THE BACKWARD  
%                            DIAGONAL TO BE COMPUTED 
INDM = INDM + 1;
%
%                        ... IF INDM > MAXCOL THEN THE ELEMENT 
%                            eps_MAXCOL^{(NUMBER_OF_CALLS-MAXCOL+1)}
%                            IS COMPUTED
IND = min([INDM,MAXCOL]);
%
%                        ... INITIALIZATION FOR THE AUXILIARY CELL ARRAY
%                            WE SET WG{2} EQUAL TO eps_{0}^(INDM)
WG{2} = EPSINI;
if (IND == 1), EPSDIF{1}= EPSINI - EPSVEC{1}; end
%
for INDS = 0:IND - 1

    if (mod(INDS,2) == 0)  
        RD = Y'*(WG{2} - EPSVEC{INDS+1});
        if (abs(RD) < TOL) % check for the denominator
            disp(['Value of denominator ',num2str(RD,'%15.5e'), ...
                  ' in odd column ', num2str(INDS+1,'%d')])
            error([' TEA1 - Division by an inner product < TOL.', ... 
                  ' Impossible to continue.'])
        end
        WG{1} = Y / RD;
        if (INDS ~= 0)
            WG{1} = WG{1} + EPSVEC{INDS};

            EPSVEC{INDS} = WG{3}; 
        end 
        WG{3} = WG{2};
        WG{2} = WG{1};
    else

%
         RD = (WG{1} - EPSVEC{INDS+1})'*EPSDIF{(INDS-1)/2+1}; 
         if (abs(RD) < TOL) 
             disp(['Value of denominator ',num2str(RD,'%15.5e'), ...
                   ' in even column ', num2str(INDS+1,'%d')])
             error([' TEA1 - Division by an inner product < TOL.', ... 
                  ' Impossible to continue.'])
         end 
%  
%                        ... COMPUTE THE TERM OF THE EVEN COLUMN
         WG{1} = EPSDIF{(INDS-1)/2+1}/RD + EPSVEC{INDS};
%  

         EPSDIF{(INDS-1)/2+1}=WG{3} - EPSVEC{INDS};
%  

         EPSVEC{INDS} = WG{3}; 
         WG{3} = WG{2};
         WG{2} = WG{1};
    end
%
%                        ... END LOOP FOR INDS
end
%  
%                        ... ADD A NEW COMPONENT TO THE VECTOR EPSDIF.
if (mod(IND-1,2) == 0), EPSDIF{(IND-1)/2+1}=WG{3} - EPSVEC{IND}; end
%  
%                        ... SAVE FOR THE FINAL VALUES OF THE BACKWORD DIAGONAL
EPSVEC{IND}   = WG{3};  
EPSVEC{IND+1} = WG{2};  
%
%                        ... SET THE RESULT VALUE
if (mod(IND,2) == 0) 
    EPSINI = EPSVEC{IND+1};  
else
    EPSINI = EPSVEC{IND};    
end