function [out] = FPI_MMPE(x,C,b, opts, mMax)
% FI_MMPE - JACOBI iteration with MMPE acceleration for solving
% the linear system Ax=b.
%
% Syntax: [out] = FI_MMPE(Q1, fun, opts, X, mcas, mMax)
%
% Inputs:
%   Q1    - Initial matrix Q1
%   fun   - Function handle for fixed-point iteration
%   opts  - Options structure containing:
%             opts.mxitr - Maximum number of iterations
%             opts.tol   - Tolerance for stopping criterion
%   X     - Input data
%   mcas  - Miscellaneous parameters
%   mMax  - Maximum number of acceleration steps
%
% Outputs:
%   out   - Structure containing:
%             out.itr    - Number of iterations performed
%             out.fval   - Final function value
%             out.Error_1 - Final Error_1
%             out.Error_2 - Final Error_2
%             out.TT     - Error_1 history

% Ensure long format for output
format long;

% Initialize variables
QQ = [];
TT = [];

x0=x;
iter1 =0; 
% Main loop for fixed-point iteration with MMPE acceleration
for iter = 1:opts.mxitr
    [F, x, Error] = Per_Jacobi(x,C,b);
    TT(iter + iter1) = F;
    QQ(:, 1) =x;
    
    % Check stopping criteria
    if Error < opts.tol || F < opts.tol 
        break;
    end
    
    % Perform MMPE acceleration over mMax steps
    for i = 1:mMax
        [F,x, Error] = Per_Jacobi(x,C,b);
        iter1 = iter1 + 1;
        TT(iter + iter1) = F;
        QQ(:, i + 1) = x;
        
        % Early stopping if convergence is met
        if Error < opts.tol || F < opts.tol 
            out.itr = iter + iter1;
            out.Residual = F;
            out.Error = Error;
            out.TT = TT;
            return;
        end
    end
    
    % Compute differences between consecutive QQ columns
    QQ(:, 2:end) = QQ(:, 2:end) - QQ(:, 1:end-1);
    QQ(:, 1) = QQ(:, 1) - x0;
    
    % Solve for gamma using partial pivoting LU decomposition
    [L, R, P] = lu(QQ);
    R_m = R(1:end-1, 1:end-1);
    L_m = L(:, 1:mMax);
    r_m = R(1:end-1, end);
    gamma = -pinv(R_m) * r_m;
    gamma = [gamma; 1];
    gamma = gamma / sum(gamma);
    
    % Update Q1 using gamma weights
    xi = 1 - cumsum(gamma(1:mMax));
    x = x0 + P' * L_m * R_m * xi;   

end

% Final output structure
out.itr = iter + iter1;
out.Residual = F;
out.Error = Error;
out.TT = TT;

end
